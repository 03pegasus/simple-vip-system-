# L2 Mafia VIP system (Lineage 2 C6, Java/L2J packs)

Untested starter code. It has NOT been compiled against a specific server pack,
so expect to adjust imports and a few method names. Back up your database and
server folder first, and test on a throwaway account.

## Contents

| Path | What it is |
|---|---|
| `sql/vip.sql` | Tables: account_vip, vip_donations, vip_pending_items, web_orders |
| `config/vip.properties` | Levels, rates, name and panel colors, package, scrolls, donation settings |
| `src/.../vip/VipManager.java` | Core logic: points, levels, rates, live refresh |
| `src/.../vip/VipDonationTask.java` | Applies verified payments (donation, package, reversal) every 30 s |
| `src/.../itemhandlers/VipScroll.java` | VIP point scrolls |
| `src/.../voicedcommandhandlers/VipCommand.java` | `.vip` panel and `.vipclaim` |
| `web/crypto_webhook.php` | Example payment webhook (adapt to your provider) |
| `preview/vip_preview.html` | Interactive visual preview (open in a browser) |
| `HOOKS.txt` | The lines to add in your own server source |

## Install

1. Run `sql/vip.sql` on your game database.
2. Copy `config/vip.properties` into the server's `config` folder.
3. Copy the `src` files into your server source and fix the imports for your pack.
4. Add the lines in `HOOKS.txt`.
5. Compile, restart, and test with a throwaway account (insert a row into
   `vip_donations` by hand and wait 30 seconds).

## Notes

- This needs a server with Java source (L2J-style). It will not work on compiled L2OFF files.
- Points are only ever credited by the server, never by the client. Payments reach the
  game only through verified website webhooks writing to `vip_donations`.
- The in-game panel uses basic L2 HTML, so it is plainer than the preview. The always-on
  badge needs a shortcut-bar icon or a client UI mod.
- Check payment, tax, and consumer rules where you operate before taking real money.
