CREATE TABLE IF NOT EXISTS account_vip (
  account_name VARCHAR(45) NOT NULL PRIMARY KEY,
  vip_points   INT NOT NULL DEFAULT 0,
  vip_level    TINYINT NOT NULL DEFAULT 0
);

CREATE TABLE IF NOT EXISTS vip_donations (
  id           INT AUTO_INCREMENT PRIMARY KEY,
  txn_id       VARCHAR(64) NOT NULL UNIQUE,
  provider     ENUM('paypal','crypto') NOT NULL,
  account_name VARCHAR(45) NOT NULL,
  euros        INT NOT NULL,
  type         ENUM('donation','package','reversal') NOT NULL DEFAULT 'donation',
  processed    TINYINT NOT NULL DEFAULT 0,
  created_at   TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS vip_pending_items (
  id           INT AUTO_INCREMENT PRIMARY KEY,
  account_name VARCHAR(45) NOT NULL,
  item_id      INT NOT NULL,
  item_count   INT NOT NULL
);

-- Website side: orders you create BEFORE sending the player to pay.
-- The webhook looks the account up here, never from the payment callback body.
CREATE TABLE IF NOT EXISTS web_orders (
  invoice_id   VARCHAR(64) NOT NULL PRIMARY KEY,
  account_name VARCHAR(45) NOT NULL,
  type         ENUM('donation','package') NOT NULL DEFAULT 'donation',
  euros        INT NOT NULL,
  created_at   TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
