<?php
// Crypto payment webhook (BTCPay / NOWPayments style).
// ADAPT the header name, field names and status value to your provider's docs.
// Only a verified server-to-server call may queue a donation. Never trust the browser.

$secret  = getenv('WEBHOOK_SECRET');
$payload = file_get_contents('php://input');
$sig     = $_SERVER['HTTP_X_SIGNATURE'] ?? '';     // header name depends on provider

if (!$secret || !hash_equals(hash_hmac('sha256', $payload, $secret), $sig)) {
    http_response_code(403);
    exit;
}

$data = json_decode($payload, true);
if (($data['status'] ?? '') !== 'confirmed') {     // credit only fully confirmed invoices
    http_response_code(200);
    exit;
}

$txn   = $data['id'] ?? '';
$euros = (int) floor($data['fiat_amount'] ?? 0);   // invoice must be priced in EUR
$type  = 'donation';

// Look the account up from YOUR OWN stored order, not from the webhook body
$pdo   = new PDO(getenv('DB_DSN'), getenv('DB_USER'), getenv('DB_PASS'));   // limited-rights DB user
$order = $pdo->prepare('SELECT account_name, type FROM web_orders WHERE invoice_id = ?');
$order->execute([$txn]);
$row = $order->fetch(PDO::FETCH_ASSOC);

if (!$row || $euros < 5) {
    http_response_code(200);
    exit;
}

$type = $row['type'] === 'package' ? 'package' : 'donation';

// UNIQUE txn_id + INSERT IGNORE: a repeated webhook can never credit twice
$st = $pdo->prepare(
    "INSERT IGNORE INTO vip_donations (txn_id, provider, account_name, euros, type)
     VALUES (?, 'crypto', ?, ?, ?)"
);
$st->execute([$txn, $row['account_name'], $euros, $type]);

http_response_code(200);
