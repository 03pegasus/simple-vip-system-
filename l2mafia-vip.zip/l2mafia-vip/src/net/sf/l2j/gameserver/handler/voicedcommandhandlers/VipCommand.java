package net.sf.l2j.gameserver.handler.voicedcommandhandlers;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

import net.sf.l2j.L2DatabaseFactory;
import net.sf.l2j.gameserver.handler.IVoicedCommandHandler;
import net.sf.l2j.gameserver.model.actor.instance.L2PcInstance;
import net.sf.l2j.gameserver.network.serverpackets.NpcHtmlMessage;
import net.sf.l2j.gameserver.vip.VipManager;

/**
 * .vip      opens the VIP panel
 * .vipclaim collects premium package items
 * Adjust imports to match your pack.
 */
public class VipCommand implements IVoicedCommandHandler
{
    private static final String[] COMMANDS = { "vip", "vipclaim" };

    public boolean useVoicedCommand(String command, L2PcInstance pc, String target)
    {
        if (command.equals("vip")) showPanel(pc);
        else if (command.equals("vipclaim")) claim(pc);
        return true;
    }

    private static String x(double v) { return String.format(Locale.US, "x%.2f", v); }

    public static void showPanel(L2PcInstance pc)
    {
        VipManager.markOpen(pc);

        String acc = pc.getAccountName();
        int points = VipManager.getPoints(acc);
        int lvl = VipManager.getLevel(acc);
        int next = VipManager.nextThreshold(lvl);
        int base = VipManager.threshold(lvl);
        String col = VipManager.panelColor(acc);

        // progress inside the current level
        int pct = next > 0 ? (points - base) * 100 / (next - base) : 100;
        int barW = Math.max(1, pct * 2);

        StringBuilder sb = new StringBuilder();
        sb.append("<html><body><center>");
        sb.append("<font color=\"").append(col).append("\">L2 MAFIA</font><br1>");
        sb.append("<font color=\"A39880\">VIP Panel</font><br>");
        sb.append("VIP level <font color=\"").append(col).append("\">").append(lvl).append("</font> / 10<br>");

        sb.append("<table width=200 height=8 bgcolor=2B241A cellspacing=0 cellpadding=0><tr>");
        sb.append("<td width=").append(barW).append(" height=8 bgcolor=").append(col).append("></td>");
        sb.append("<td></td></tr></table>");

        sb.append("<br1>").append(points).append(" points");
        if (next > 0) sb.append(" (").append(next - points).append(" to VIP ").append(lvl + 1).append(")");
        else sb.append(" (max level)");
        sb.append("<br>");

        sb.append("<table width=250 bgcolor=1C1A15>");
        sb.append("<tr><td width=90></td><td width=80><font color=\"A39880\">Now</font></td><td width=80><font color=\"A39880\">Next</font></td></tr>");
        perk(sb, "XP / SP", VipManager.xpRate(lvl), lvl < 10 ? VipManager.xpRate(lvl + 1) : -1);
        perk(sb, "Adena", VipManager.adenaRate(lvl), lvl < 10 ? VipManager.adenaRate(lvl + 1) : -1);
        perk(sb, "Drop", VipManager.dropRate(lvl), lvl < 10 ? VipManager.dropRate(lvl + 1) : -1);
        sb.append("</table><br>");

        sb.append("<font color=\"A39880\">Type .vipclaim to collect package items</font>");
        sb.append("</center></body></html>");

        NpcHtmlMessage html = new NpcHtmlMessage(5);
        html.setHtml(sb.toString());
        pc.sendPacket(html);
    }

    private static void perk(StringBuilder sb, String name, double now, double nxt)
    {
        sb.append("<tr><td>").append(name).append("</td>");
        sb.append("<td>").append(x(now)).append("</td>");
        sb.append("<td>");
        if (nxt > 0) sb.append("<font color=\"7AD07A\">").append(x(nxt)).append("</font>");
        else sb.append("max");
        sb.append("</td></tr>");
    }

    private void claim(L2PcInstance pc)
    {
        String acc = pc.getAccountName();
        List<int[]> rows = new ArrayList<int[]>();

        Connection con = null;
        try
        {
            con = L2DatabaseFactory.getInstance().getConnection();

            PreparedStatement sel = con.prepareStatement("SELECT id, item_id, item_count FROM vip_pending_items WHERE account_name=?");
            sel.setString(1, acc);
            ResultSet rs = sel.executeQuery();
            while (rs.next())
                rows.add(new int[] { rs.getInt(1), rs.getInt(2), rs.getInt(3) });
            rs.close();
            sel.close();

            int given = 0;
            for (int[] r : rows)
            {
                // delete first, so a row can never be claimed twice
                PreparedStatement del = con.prepareStatement("DELETE FROM vip_pending_items WHERE id=?");
                del.setInt(1, r[0]);
                int n = del.executeUpdate();
                del.close();

                if (n == 1)
                {
                    pc.addItem("VipClaim", r[1], r[2], pc, true);
                    given++;
                }
            }
            pc.sendMessage(given > 0 ? "Package items delivered." : "You have no pending items.");
        }
        catch (Exception e) { e.printStackTrace(); }
        finally { try { if (con != null) con.close(); } catch (Exception ignored) {} }
    }

    public String[] getVoicedCommandList() { return COMMANDS; }
}
