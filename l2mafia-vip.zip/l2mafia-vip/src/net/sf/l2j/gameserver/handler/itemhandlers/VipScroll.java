package net.sf.l2j.gameserver.handler.itemhandlers;

import net.sf.l2j.gameserver.handler.IItemHandler;
import net.sf.l2j.gameserver.model.L2ItemInstance;
import net.sf.l2j.gameserver.model.actor.instance.L2PcInstance;
import net.sf.l2j.gameserver.model.actor.instance.L2PlayableInstance;
import net.sf.l2j.gameserver.vip.VipManager;

/**
 * VIP point scrolls. Item ids must match "Scrolls" in config/vip.properties.
 * Adjust imports to match your pack.
 */
public class VipScroll implements IItemHandler
{
    private static final int[] ITEM_IDS = { 9001, 9002, 9003 };

    public void useItem(L2PlayableInstance playable, L2ItemInstance item)
    {
        if (!(playable instanceof L2PcInstance)) return;
        L2PcInstance player = (L2PcInstance) playable;

        int pts = VipManager.getScrollPoints(item.getItemId());
        if (pts <= 0) return;

        // The scroll is destroyed first, so it can never be reused
        if (!player.destroyItem("VipScroll", item.getObjectId(), 1, player, true)) return;

        String acc = player.getAccountName();
        int before = VipManager.getLevel(acc);
        int after = VipManager.addPoints(acc, pts);

        player.sendMessage("+" + pts + " VIP points.");
        if (after > before)
            player.sendMessage("VIP level up! You are now VIP " + after + ".");
    }

    public int[] getItemIds() { return ITEM_IDS; }
}
