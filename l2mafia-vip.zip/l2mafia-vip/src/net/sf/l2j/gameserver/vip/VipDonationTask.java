package net.sf.l2j.gameserver.vip;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import net.sf.l2j.L2DatabaseFactory;

/**
 * Reads verified payments queued by the website (vip_donations) and applies them.
 * Schedule process() every ~30 seconds.
 */
public class VipDonationTask implements Runnable
{
    public void run() { process(); }

    public static void process()
    {
        List<Object[]> rows = new ArrayList<Object[]>();
        Connection con = null;
        try
        {
            con = L2DatabaseFactory.getInstance().getConnection();

            PreparedStatement sel = con.prepareStatement("SELECT id, account_name, euros, type FROM vip_donations WHERE processed=0");
            ResultSet rs = sel.executeQuery();
            while (rs.next())
                rows.add(new Object[] { rs.getInt(1), rs.getString(2), rs.getInt(3), rs.getString(4) });
            rs.close();
            sel.close();

            for (Object[] r : rows)
            {
                int id = (Integer) r[0];
                String acc = (String) r[1];
                int euros = (Integer) r[2];
                String type = (String) r[3];

                // mark as processed first, so a crash can never credit twice
                PreparedStatement upd = con.prepareStatement("UPDATE vip_donations SET processed=1 WHERE id=? AND processed=0");
                upd.setInt(1, id);
                int n = upd.executeUpdate();
                upd.close();
                if (n != 1) continue;

                if ("package".equals(type)) VipManager.grantPackage(acc);
                else if ("reversal".equals(type)) VipManager.reverseDonation(acc, euros);
                else VipManager.addDonation(acc, euros);
            }
        }
        catch (Exception e) { e.printStackTrace(); }
        finally { try { if (con != null) con.close(); } catch (Exception ignored) {} }
    }
}
