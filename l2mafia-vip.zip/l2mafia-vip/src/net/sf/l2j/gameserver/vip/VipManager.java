package net.sf.l2j.gameserver.vip;

import java.io.FileInputStream;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;

import net.sf.l2j.L2DatabaseFactory;
import net.sf.l2j.gameserver.handler.voicedcommandhandlers.VipCommand;
import net.sf.l2j.gameserver.model.L2World;
import net.sf.l2j.gameserver.model.actor.instance.L2PcInstance;

/**
 * L2 Mafia VIP system. Adjust the imports above to match your pack.
 */
public class VipManager
{
    public static final int MAX_LEVEL = 10;

    private static int[] THRESHOLDS;
    private static double[] XP, ADENA, DROP;
    private static int[] NAME_COLOR;
    private static String[] PANEL_COLOR;
    private static int PACKAGE_MIN_LEVEL, EURO_TO_POINTS, MIN_EUR;

    private static final Map<Integer, Integer> SCROLLS = new HashMap<Integer, Integer>();
    private static final List<int[]> PACKAGE_ITEMS = new ArrayList<int[]>();

    // account -> {points, level}; avoids a DB hit on every monster kill
    private static final Map<String, int[]> CACHE = new ConcurrentHashMap<String, int[]>();

    // players who have the panel open (refreshed when points change)
    private static final Set<Integer> OPEN = Collections.newSetFromMap(new ConcurrentHashMap<Integer, Boolean>());

    public static void load()
    {
        FileInputStream in = null;
        try
        {
            in = new FileInputStream("config/vip.properties");
            Properties p = new Properties();
            p.load(in);

            THRESHOLDS = ints(p.getProperty("Thresholds"));
            XP = doubles(p.getProperty("XpSpRates"));
            ADENA = doubles(p.getProperty("AdenaRates"));
            DROP = doubles(p.getProperty("DropRates"));

            String[] colors = p.getProperty("NameColors").split(",");
            NAME_COLOR = new int[colors.length];
            for (int i = 0; i < colors.length; i++)
                NAME_COLOR[i] = Integer.parseInt(colors[i].trim(), 16);

            PANEL_COLOR = p.getProperty("PanelColors").split(",");
            for (int i = 0; i < PANEL_COLOR.length; i++)
                PANEL_COLOR[i] = PANEL_COLOR[i].trim();

            PACKAGE_MIN_LEVEL = Integer.parseInt(p.getProperty("PackageMinLevel").trim());
            EURO_TO_POINTS = Integer.parseInt(p.getProperty("EuroToPoints").trim());
            MIN_EUR = Integer.parseInt(p.getProperty("MinDonationEur").trim());

            SCROLLS.clear();
            for (String s : p.getProperty("Scrolls").split(";"))
            {
                String[] a = s.split(":");
                SCROLLS.put(Integer.parseInt(a[0].trim()), Integer.parseInt(a[1].trim()));
            }

            PACKAGE_ITEMS.clear();
            for (String s : p.getProperty("PackageItems").split(";"))
            {
                String[] a = s.split(":");
                PACKAGE_ITEMS.add(new int[] { Integer.parseInt(a[0].trim()), Integer.parseInt(a[1].trim()) });
            }
        }
        catch (Exception e)
        {
            throw new RuntimeException("Error loading config/vip.properties", e);
        }
        finally
        {
            try { if (in != null) in.close(); } catch (Exception ignored) {}
        }
    }

    private static int[] ints(String s)
    {
        String[] a = s.split(",");
        int[] r = new int[a.length];
        for (int i = 0; i < a.length; i++) r[i] = Integer.parseInt(a[i].trim());
        return r;
    }

    private static double[] doubles(String s)
    {
        String[] a = s.split(",");
        double[] r = new double[a.length];
        for (int i = 0; i < a.length; i++) r[i] = Double.parseDouble(a[i].trim());
        return r;
    }

    // ---------- levels ----------

    public static int calcLevel(int points)
    {
        int lvl = 0;
        for (int i = 1; i <= MAX_LEVEL; i++)
            if (points >= THRESHOLDS[i]) lvl = i;
        return lvl;
    }

    public static int threshold(int level) { return THRESHOLDS[level]; }

    public static int nextThreshold(int level) { return level >= MAX_LEVEL ? -1 : THRESHOLDS[level + 1]; }

    // ---------- storage ----------

    private static int[] fetch(String account)
    {
        int[] v = CACHE.get(account);
        if (v != null) return v;

        v = new int[] { 0, 0 };
        Connection con = null;
        try
        {
            con = L2DatabaseFactory.getInstance().getConnection();
            PreparedStatement ps = con.prepareStatement("SELECT vip_points, vip_level FROM account_vip WHERE account_name=?");
            ps.setString(1, account);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) { v[0] = rs.getInt(1); v[1] = rs.getInt(2); }
            rs.close();
            ps.close();
        }
        catch (Exception e) { e.printStackTrace(); }
        finally { try { if (con != null) con.close(); } catch (Exception ignored) {} }

        CACHE.put(account, v);
        return v;
    }

    public static int getPoints(String account) { return fetch(account)[0]; }

    public static int getLevel(String account) { return fetch(account)[1]; }

    private static void save(String account, int total, int level)
    {
        Connection con = null;
        try
        {
            con = L2DatabaseFactory.getInstance().getConnection();
            PreparedStatement ps = con.prepareStatement("REPLACE INTO account_vip (account_name, vip_points, vip_level) VALUES (?,?,?)");
            ps.setString(1, account);
            ps.setInt(2, total);
            ps.setInt(3, level);
            ps.execute();
            ps.close();
            CACHE.put(account, new int[] { total, level });
        }
        catch (Exception e) { e.printStackTrace(); }
        finally { try { if (con != null) con.close(); } catch (Exception ignored) {} }
    }

    /** Adds points. Returns the new level. */
    public static synchronized int addPoints(String account, int amount)
    {
        int total = getPoints(account) + amount;
        int level = calcLevel(total);
        save(account, total, level);
        refresh(account);
        return level;
    }

    /** Removes points (refund, chargeback, correction). Returns the new level. */
    public static synchronized int removePoints(String account, int amount)
    {
        int total = Math.max(0, getPoints(account) - amount);
        int level = calcLevel(total);
        save(account, total, level);
        refresh(account);
        return level;
    }

    // ---------- sources of points ----------

    public static int getScrollPoints(int itemId)
    {
        Integer v = SCROLLS.get(itemId);
        return v == null ? 0 : v.intValue();
    }

    /** Premium package: guarantee at least PackageMinLevel, never lowers a higher level. */
    public static void grantPackage(String account)
    {
        int need = THRESHOLDS[PACKAGE_MIN_LEVEL] - getPoints(account);
        if (need > 0) addPoints(account, need);

        Connection con = null;
        try
        {
            con = L2DatabaseFactory.getInstance().getConnection();
            PreparedStatement ps = con.prepareStatement("INSERT INTO vip_pending_items (account_name, item_id, item_count) VALUES (?,?,?)");
            for (int[] it : PACKAGE_ITEMS)
            {
                ps.setString(1, account);
                ps.setInt(2, it[0]);
                ps.setInt(3, it[1]);
                ps.addBatch();
            }
            ps.executeBatch();
            ps.close();
        }
        catch (Exception e) { e.printStackTrace(); }
        finally { try { if (con != null) con.close(); } catch (Exception ignored) {} }
    }

    public static void addDonation(String account, int euros)
    {
        if (euros < MIN_EUR) return;
        addPoints(account, euros * EURO_TO_POINTS);
    }

    public static void reverseDonation(String account, int euros)
    {
        removePoints(account, euros * EURO_TO_POINTS);
    }

    // ---------- rates and looks ----------

    public static double xpRate(int level) { return XP[level]; }
    public static double adenaRate(int level) { return ADENA[level]; }
    public static double dropRate(int level) { return DROP[level]; }

    public static double xpMult(String acc) { return XP[getLevel(acc)]; }
    public static double adenaMult(String acc) { return ADENA[getLevel(acc)]; }
    public static double dropMult(String acc) { return DROP[getLevel(acc)]; }

    public static int nameColor(String acc) { return NAME_COLOR[getLevel(acc)]; }
    public static String panelColor(String acc) { return PANEL_COLOR[getLevel(acc)]; }

    // ---------- live refresh ----------

    public static void markOpen(L2PcInstance pc) { OPEN.add(pc.getObjectId()); }

    /** Updates name color and re-sends the panel to players who have it open. */
    public static void refresh(String account)
    {
        for (L2PcInstance pc : L2World.getInstance().getAllPlayers())
        {
            if (pc == null || !account.equals(pc.getAccountName())) continue;

            pc.getAppearance().setNameColor(nameColor(account));
            pc.broadcastUserInfo();

            if (OPEN.contains(pc.getObjectId()))
                VipCommand.showPanel(pc);
        }
    }
}
